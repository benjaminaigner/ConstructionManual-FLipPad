Teensy libraries & footprints are provided by XenGi:
https://github.com/XenGi/teensy_library